<?php include "includes/header.php";?>
<style>
select{
	height: 40px;
	width: 300px;
	border-radius:5px;
}
button{
	border-radius:5px;
	background:lightgreen;
	height: 35px;
}
</style>
<?php include "includes/config.php";
session_start();
  if(!isset($_SESSION['username'])){
	  echo"";
	  header("location:login.php");
  }
  
?>
<br>
<section style ="height:auto; width:100%;">
<form method ="post">
<button name ="logout" type ="submit">Log Out</button>
</form>
<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
?>
Check the symptoms you notice you have
<br>
<div>
   <form method ="post">
   <br>
   <select name ="symptom1">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
   <select name ="symptom2">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   </select>
   <br><br> 
   <select name ="symptom3">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
   <select name ="symptom4">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
   <select name ="symptom5">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
   <select name ="symptom6">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
   <select name ="symptom7">
   <option value ="Joint and limb swelling">Joint and limb swelling</option>
   <option value ="Limb and joint tenderness">Limb and joint tenderness</option>
   <option value ="Limb and joint pain">Limb and joint pain</option>
   <option value ="Hand and finger numbness">Hand and finger numbness</option>
   <option value ="Finger shock-like feeling">Finger shock-like feeling</option>
   <option value ="Arm tingling">Arm tingling</option>
   <option value ="Tenderness of your limbs">Joint Stiffness</option>
   <option value ="Loss of flexibility">Loss of flexibility</option>
   <option value ="Joint cracking">Joint cracking</option>
   <option value ="Bone spurs">Bone spurs</option>
   <option value ="Constant fatigue">Constant fatigue</option>
   <option value ="Lack of Concentration">Lack of Concentration</option>
   <option value ="General pain">General pain</option>
   <option value ="Misplaced bone">Misplaced bone</option>
   <option value ="Bleeding">Bleeding</option>
   <option value ="Intense pain">Intense pain</option>
   <option value ="Limb tingling">Limb tingling</option>
   <option value ="Protruding bone">Protruding bone</option>
   <option value ="Limited mobility">Limited mobility</option>
   </select>
   <br><br>
  <button type ="submit" name ="submit">Submit</button>
   </form>
</div>

<?php
if(isset($_POST['submit'])){
	$symptom1 = $_POST['symptom1'];
	$symptom2 = $_POST['symptom2'];
	$symptom3 = $_POST['symptom3'];
	$symptom4 = $_POST['symptom4'];
	$symptom5 = $_POST['symptom5'];
	$symptom6 = $_POST['symptom6'];
	$symptom7 = $_POST['symptom7'];
	$session = $_SESSION['username'];
	
	if(($symptom1 =="Joint and limb swelling") && ($symptom2 =="Limb and joint tenderness") && ($symptom3 =="Limb and joint pain")){
		$diagnosis ="Tendritis";
		
	}
	if(($symptom1 =="Hand and finger numbness") && ($symptom2 =="Arm tingling") && ($symptom3 =="Finger shock-like feeling")){
		$diagnosis ="Carpel Tunnel Syndrome";
		
	}
	if(($symptom1 =="Limb and joint pain") && ($symptom2 =="Joint Stiffness") && ($symptom3 =="Loss of flexibility") && ($symptom4 =="Limb and joint pain") && ($symptom5 =="Joint cracking") && ($symptom6 =="Joint and limb swelling") && ($symptom7 =="Bone spurs")){
		$diagnosis ="Osteoarthritis";
		
	}
	if(($symptom1 =="Joint Stiffness") && ($symptom2 =="Limb and joint tenderness") && ($symptom3 =="Joint and limb swelling")){
		$diagnosis ="Rheumatoid Arthritis";
		
	}
	if(($symptom1 =="Constant fatigue") && ($symptom2 =="Lack of concentration") && ($symptom3 =="General pain")){
		$diagnosis ="Fibromgalgia";
		
	}
	if(($symptom1 =="Misplaced bone") && ($symptom2 =="Bleeding") && ($symptom3 =="Intense pain") && ($symptom4 =="Limb tingling") && ($symptom5 =="Protruding bone") && ($symptom6 =="Limited mobility")){
		$diagnosis ="Bone fracture";
		
	}
	
	
$query = "UPDATE user SET diagnosis = '$diagnosis' WHERE username = '$session'";
$query_run =mysqli_query ($connection, $query);
	
	if($query_run){
		
		echo "You may have". " ". $diagnosis;
	}
	else{
		echo'<script type ="text/javascript"> alert("Error")</script>';
		
	}
}

?>
</section>


<?php include "includes/footer.php";?>