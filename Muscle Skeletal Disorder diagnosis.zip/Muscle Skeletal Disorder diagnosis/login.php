<?php include "includes/header.php"?>
<?php include "includes/config.php"?>
<br>
<center>
<section style ="height:400px; width:121px;">

<fieldset style ="height:220px; width:150px; border-radius:5px; background:cyan;">
<?php

if(isset($_POST['submit'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$query ="SELECT username, password from user where username ='$username' and password ='$password'";
	$query_run = mysqli_query($connection, $query);
	if($query_run -> num_rows > 0){
		session_start();
		$_SESSION['username'] = $username;
		header("location:dashboard.php");
		}
	else{
		echo "Error!";
	}
	
	
	
}



?>
<div>
  <form action ="" method ="post">
  <p align ="left">Username<br>
  <input type ="text" name ="username" style ="height:40px; width:150px; border-radius:12px;" required></input><br>
  
  <p align ="left">Password<br>
  <input type ="password" name ="password" style ="height:40px; width:150px; border-radius:12px;" required></input><br>

  <center>
  <button align ="center" type ="submit" name ="submit" style ="height:40px; width:80px; background:lightgreen; border-radius:12px;">Submit</button>
  </center>
  
  </form>
<div>
</fieldset>

</body>
</section>
<br>
<?php include "includes/footer.php"?>