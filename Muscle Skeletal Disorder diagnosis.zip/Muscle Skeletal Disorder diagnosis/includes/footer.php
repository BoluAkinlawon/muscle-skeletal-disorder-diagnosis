<html>
<center>
<div style ="background:cyan; height:60px; width:80%;">
</center>
</html>