create a database "muscle_disorder"
Import the muscle_disorder.sql file into it

