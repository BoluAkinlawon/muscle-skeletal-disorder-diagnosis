<html>

<head>
<title>Muscle Skeletal Disorder Diagnosis</title>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
<meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">

<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="shortcut icon" href="images/logo.ico" />
<style>
body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 12px;
      font-size: 12px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
	  
	  /* Media Queries: Tablet Landscape */
@media screen and (max-width: 1060px) {
    #primary { width:67%; }
    #secondary { width:30%; margin-left:3%;}  
}

/* Media Queries: Tabled Portrait */
@media screen and (max-width: 768px) {
    #primary { width:100%; }
    #secondary { width:100%; margin:0; border:none; }
}

 #leftbox { 
                float:left;  
                background:lightblue; 
                width:50%; 
                height:130px;
				
                			
            } 
             
            #rightbox{ 
                float:right; 
                background:cyan; 
                width:50%; 
                height:130px;
                				
            } 
            h1{ 
                color:green; 
                text-align:center; 
            } 
			

* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  height: 400px;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

</style>
</head>
<body>
<hr>
<center>

</center>
<br>
<center>
<div style ="background:cyan; height:60px; width:80%;">
<a href ="index.php" style ="text-decoration:none;"><button style ="height:60px; width:120px; background:lightgreen; border-radius:5px;">Home</button></a>
<a href ="register.php" style ="text-decoration:none;"><button style ="height:60px; width:120px; background:lightgreen; border-radius:5px;">Sign Up</button></a>
<a href ="dashboard.php" style ="text-decoration:none;"><button style ="height:60px; width:120px; background:lightgreen; border-radius:5px;">Log In</button></a>



</div>
</center>

<section style ="height:auto; width:100%;">
<?php include "includes/config.php";
?>




<div style ="height:450px; width:100%;">


<center>
<h1> MUSCLE SKELETAL DISORDER DIAGNOSIS SYSTEM</h1>
This diagnoses the following:
 <br><br>
 Tendiritis
 <br><br>
 Carpel tunnel Syndrome
 <br><br>
 Osteoarthritis
 <br><br>
 Rheumatoid Arthritis
 <br><br>
 Fibromgalgia
 <br><br>
 Bone fractures
 <br><br>
</center>

</div>
</section>


<center>
<div style ="background:cyan; height:60px; width:80%;">
</center>
</body>
</html>