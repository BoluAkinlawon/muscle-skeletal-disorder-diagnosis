<?php include "includes/header.php"?>
<?php include "includes/config.php"?>
<br>
<center>
<section style ="height:430px; width:121px;">

<fieldset style ="height:420px; width:150px; border-radius:5px; background:cyan;">

<?php

if (isset($_POST['submit'])){
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	
	$query ="INSERT INTO user (firstname, lastname, username, email, password) VALUES ('$firstname', '$lastname', '$username', '$email', '$password')";
	$query_run = mysqli_query($connection, $query);
	if($query_run){
		header("location:login.php");	
	}
	else{
		"Error!";
	}
}

?>

<div>
  <form action ="" method ="post">
  <p align ="left">Firstname<br>
  <input type ="text" name ="firstname" style ="height:40px; width:150px; border-radius:12px;" required></input><br>
  
  <p align ="left">Lastname<br>
  <input type ="text" name ="lastname" style ="height:40px; width:150px; border-radius:12px;" required></input><br>
  
  <p align ="left">Username<br>
  <input type ="text" name ="username" style ="height:40px; width:150px; border-radius:12px;" required></input><br>
  
  <p align ="left">Email<br>
  <input type ="email" name ="email" style ="height:40px; width:150px; border-radius:12px;" required></input><br>
  
  <p align ="left">Password<br>
  <input type ="password" name ="password" style ="height:40px; width:150px; border-radius:12px;" required></input><br>

  <center>
  <button align ="center" type ="submit" name ="submit" style ="height:40px; width:80px; background:lightgreen; border-radius:12px;">Submit</button>
  </center>
  
  </form>
<div>
</fieldset>

</body>
</section>
<br>
<?php include "includes/footer.php"?>